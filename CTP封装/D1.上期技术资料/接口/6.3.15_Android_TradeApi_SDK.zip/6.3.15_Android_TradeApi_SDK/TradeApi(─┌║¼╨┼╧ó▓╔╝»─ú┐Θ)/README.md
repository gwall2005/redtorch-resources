# 1. 文件目录结构说明
	主目录
	|
	|-TradeApi_release_v1.4-xxx.aar:TradeApi模块aar文件。

TradeApi_release_v1.4-xxx.aar集成了TradeApi和信息采集模块所需内容，无需再额外添加信息采集模块。
PS:xxx代表日期。

模块中提供的登录接口(CThostFtdcTraderApi->ReqUserLogin)，内部自动获取采集信息并完成上报，无需使用者手动调用获取采集信息接口。

# 2. 开发环境要求

开发者需要配置Kotlin开发环境，否则可能无法正常使用。


# 3. 应用权限配置

模块内部在获取采集信息时，首先会判断应用是否具备对应的权限，若无权限则涉及到采集项会无法获取。
因此在使用信息采集模块前，应用需要请申请权限。

使用到的权限如下(可能会根据需求变动)：
​    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
​    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
​    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
​    <uses-permission android:name="android.permission.INTERNET"/>
​    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
​    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>


# 4. 支持

目前SDK支持armeabi结构，不支持x86架构。

# 5. 如何配置并使用aar

1. 将aar文件放入moudle中的libs文件夹下。
2. 修改module的build.gradle文件，添加如下配置：
android {  
	repositories{
        flatDir{
            dirs "libs"
        }
    }
}

dependencies {
	compile(name: "TradeApi_release_v1.4-2019-03-06", ext: "aar")
}


# 6. 代码示例

示例使用Kotlin语言描述。

TradeApi在登录前，需要先认证，认证成功后才能进行登录，否则可能导致登录失败。


## 6.1 加载动态库

```java
static{
	System.loadLibrary("thosttraderapi")
	System.loadLibrary("thosttraderapi_wrap")
}
```

## 6.2 初始化API

```
	fun initTradeApi() {
		Global.sTradeApi = CThostFtdcTraderApi.CreateFtdcTraderApi(apppath)
		// CTPTradeHandler继承CThostFtdcTraderSpi，负责事件回调处理
		traderHandler = CTPTradeHandler()
		Global.sTradeApi.RegisterSpi(traderHandler)
		Global.sTradeApi.RegisterFront(ConfigReader.m_strFrontAddr)
		Global.sTradeApi.SubscribePublicTopic(THOST_TE_RESUME_TYPE.swigToEnum(ConfigReader.m_iResumeType))
		Global.sTradeApi.SubscribePrivateTopic(THOST_TE_RESUME_TYPE.swigToEnum(ConfigReader.m_iResumeType))
		Global.sTradeApi.Init()
	}
```


## 6.3 认证

```
	fun ReqAuthenticate() {
		val field = CThostFtdcReqAuthenticateField()
		field.brokerID = ConfigReader.m_strBrokerID
		field.userID = ConfigReader.m_strInvestorID
		field.userProductInfo = ConfigReader.m_strProductInfo
		// AuthCode与AppID需要申请
		field.authCode = ConfigReader.m_strAuthenCode
		field.appID = ConfigReader.m_strAppId
		val code = Global.sTradeApi?.ReqAuthenticate(field, 10000)
		Log.e("===", "ReqAuthenticate:$code")
	}

```

对应的CTPTradeHandler事件回调为：CTPTradeHandler->OnRspAuthenticate.


## 6.4 登录

```
	fun ReqUserLogin(context:Context) {
		// 调用接口获取采集信息
		val loginFiled = CThostFtdcReqUserLoginField()
		loginFiled.brokerID = ConfigReader.m_strBrokerID
		loginFiled.userID = ConfigReader.m_strInvestorID
		loginFiled.password = ConfigReader.m_strPassword
		loginFiled.userProductInfo = ConfigReader.m_strProductInfo
		// 调用登录接口进行登录，注意需要使用参数context
		val code = Global.sTradeApi.ReqUserLogin(context,loginFiled,10001)
		Log.e("===", "ReqUserLogin:$code")
	}

```
对应的CTPTradeHandler事件回调为：CTPTradeHandler->OnRspUserLogin.

PS:登录接口内部自动完成信息采集和上报。