# 1. 说明

文件名称：InfoCollection_single_release_v1.4-xxxxx.aar

xxx代表编译的日期。

该文件仅适用于单独采集信息的情景。

# 2. 开发环境要求

开发者需要配置Kotlin开发环境，否则采集模块可能无法正常使用。


# 3. 应用权限配置

信息采集模块采集信息时，需要应用具备某些权限。若应用不具备某些权限，可能会导致获取到对应的采集项为空。因此在使用信息采集模块前， 请使用者申请权限。

使用到的权限如下(可能会根据需求变动)：
```
​    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
​    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
​    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
​    <uses-permission android:name="android.permission.INTERNET"/>
​    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
​    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```


# 4. 支持

目前SDK支持armeabi和armeabi-v7a结构，不支持x86架构。

# 5. 如何配置并使用aar

1. 将aar文件放入moudle中的libs文件夹下。
2. 修改module的build.gradle文件，添加如下配置：
android {  
	repositories{
        flatDir{
            dirs "libs"
        }
    }
}

dependencies {
	compile(name: "InfoCollection_single_release_v1.4-2019-03-06", ext: "aar")
}

# 6. 代码示例

PS:直接调用接口，无需自己手动加载动态库。

```java
byte[] collectInfo = DeviceInfoManager.getCollectInfo(context);
```


